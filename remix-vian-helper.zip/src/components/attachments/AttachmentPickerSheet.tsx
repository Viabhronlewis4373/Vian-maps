import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FolderDown, Image as ImageIcon, Palette, Table, X } from 'lucide-react';
import { Attachment } from '../../types';

interface AttachmentPickerSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onPickFold: () => void;
  onPickDrawing: () => void;
  onPickTable: () => void;
  onPickImage: (attachment: Attachment) => void;
}

export const AttachmentPickerSheet: React.FC<AttachmentPickerSheetProps> = ({
  isOpen,
  onClose,
  onPickFold,
  onPickDrawing,
  onPickTable,
  onPickImage,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      onPickImage({
        type: 'image',
        data: dataUrl,
        name: file.name,
      });
      onClose();
    };
    reader.readAsDataURL(file);
    // Reset file input value
    e.target.value = '';
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200005] flex flex-col justify-end">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"
          />

          {/* Hidden File Input for Image */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleImageFile}
          />

          {/* Bottom Sheet */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 280 }}
            className="relative z-10 bg-white rounded-t-2xl shadow-2xl p-5 pb-8 max-w-lg mx-auto w-full border-t border-black/10"
          >
            {/* Sheet Handle */}
            <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4" />

            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">Insert into Note</h3>
              <button
                onClick={onClose}
                className="p-1 rounded-full text-gray-500 hover:bg-gray-100 transition"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {/* Fold Section */}
              <button
                onClick={() => {
                  onClose();
                  onPickFold();
                }}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl bg-amber-50 hover:bg-amber-100 active:scale-95 border border-amber-200/80 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-md mb-2 group-hover:scale-105 transition-transform">
                  <FolderDown size={24} strokeWidth={2.5} />
                </div>
                <span className="font-bold text-xs sm:text-sm text-gray-900">Fold Section</span>
                <span className="text-[10px] text-gray-500 mt-0.5 leading-tight">
                  2-line foldable
                </span>
              </button>

              {/* Image */}
              <button
                onClick={() => {
                  fileInputRef.current?.click();
                }}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl bg-sky-50 hover:bg-sky-100 active:scale-95 border border-sky-200/80 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-md mb-2 group-hover:scale-105 transition-transform">
                  <ImageIcon size={24} strokeWidth={2.5} />
                </div>
                <span className="font-bold text-xs sm:text-sm text-gray-900">Image</span>
                <span className="text-[10px] text-gray-500 mt-0.5 leading-tight">
                  Gallery / Camera
                </span>
              </button>

              {/* Table */}
              <button
                onClick={() => {
                  onClose();
                  onPickTable();
                }}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:scale-95 border border-teal-200/80 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center shadow-md mb-2 group-hover:scale-105 transition-transform">
                  <Table size={24} strokeWidth={2.5} />
                </div>
                <span className="font-bold text-xs sm:text-sm text-gray-900">Table</span>
                <span className="text-[10px] text-gray-500 mt-0.5 leading-tight">
                  Rows & Columns
                </span>
              </button>

              {/* Drawing */}
              <button
                onClick={() => {
                  onClose();
                  onPickDrawing();
                }}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl bg-purple-50 hover:bg-purple-100 active:scale-95 border border-purple-200/80 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-md mb-2 group-hover:scale-105 transition-transform">
                  <Palette size={24} strokeWidth={2.5} />
                </div>
                <span className="font-bold text-xs sm:text-sm text-gray-900">Drawing</span>
                <span className="text-[10px] text-gray-500 mt-0.5 leading-tight">
                  Sketch pad
                </span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
