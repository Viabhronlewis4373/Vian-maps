import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2 } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title?: string;
  message?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  title = 'Delete Attachment?',
  message = 'Are you sure you want to remove this attachment from this note? This cannot be undone.',
  onConfirm,
  onCancel,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200050] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white w-full max-w-xs shadow-2xl rounded-2xl overflow-hidden border border-black/10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 mx-auto flex items-center justify-center mb-3">
                <Trash2 size={24} />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">{title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{message}</p>
            </div>
            <div className="grid grid-cols-2 border-t border-gray-100 bg-gray-50/90">
              <button
                type="button"
                onClick={onCancel}
                className="py-3 text-xs font-bold text-gray-600 hover:bg-gray-200/70 transition border-r border-gray-100"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={onConfirm}
                className="py-3 text-xs font-bold text-red-600 hover:bg-red-50 transition"
              >
                DELETE
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
