import React, { useRef, useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Eraser, RotateCcw, Trash2 } from 'lucide-react';
import { Attachment } from '../../types';

interface DrawingModalProps {
  onSave: (attachment: Attachment) => void;
  onClose: () => void;
  initialData?: string;
}

const COLORS = [
  '#1a1a1a',
  '#ef4444',
  '#3b82f6',
  '#22c55e',
  '#f97316',
  '#a855f7',
  '#eab308',
  '#ffffff',
];

const SIZES = [
  { label: 'S', size: 3 },
  { label: 'M', size: 7 },
  { label: 'L', size: 14 },
];

export const DrawingModal: React.FC<DrawingModalProps> = ({ onSave, onClose, initialData }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [color, setColor] = useState(COLORS[0]);
  const [brushSize, setBrushSize] = useState(7);
  const [isEraser, setIsEraser] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasContent, setHasContent] = useState(false);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions based on client size
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, rect.width, rect.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (initialData) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, rect.width, rect.height);
        setHasContent(true);
      };
      img.src = initialData;
    }
  }, [initialData]);

  const lastPosRef = useRef<{ x: number; y: number } | null>(null);

  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);

    const pos = getCoordinates(e);
    lastPosRef.current = pos;
    setIsDrawing(true);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, (isEraser ? 20 : brushSize) / 2, 0, Math.PI * 2);
    ctx.fillStyle = isEraser ? '#ffffff' : color;
    ctx.fill();
    setHasContent(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !lastPosRef.current) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(lastPosRef.current.x, lastPosRef.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = isEraser ? '#ffffff' : color;
    ctx.lineWidth = isEraser ? 24 : brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();

    lastPosRef.current = pos;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setIsDrawing(false);
    lastPosRef.current = null;
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, rect.width, rect.height);
    setHasContent(false);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSave({
      type: 'drawing',
      data: dataUrl,
      name: `drawing_${Date.now()}.png`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200010] bg-black/70 backdrop-blur-sm flex flex-col justify-end sm:justify-center sm:p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="w-full h-full max-w-2xl mx-auto bg-[#F5F5F5] flex flex-col shadow-2xl overflow-hidden sm:rounded-xl sm:h-[85vh]"
      >
        {/* Header / Toolbar */}
        <div className="h-16 bg-[#212121] text-white flex items-center justify-between px-3 shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full active:scale-95 transition"
            >
              <ArrowLeft size={26} />
            </button>
            <span className="font-bold text-lg tracking-wide">Drawing Pad</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClear}
              className="p-2.5 text-gray-300 hover:text-white hover:bg-white/10 rounded-full transition"
              title="Clear Canvas"
            >
              <Trash2 size={20} />
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 bg-[#0D9488] hover:bg-[#0F766E] text-white rounded-lg font-bold flex items-center gap-1.5 shadow active:scale-95 transition"
            >
              <Check size={18} strokeWidth={3} />
              <span>Save</span>
            </button>
          </div>
        </div>

        {/* Tools Sub-bar */}
        <div className="bg-white border-b border-gray-200 px-3 py-2 flex items-center justify-between gap-2 overflow-x-auto shrink-0 shadow-sm">
          {/* Colors */}
          <div className="flex items-center gap-1.5">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setColor(c);
                  setIsEraser(false);
                }}
                className={`w-7 h-7 rounded-full border-2 transition-transform ${
                  !isEraser && color === c ? 'scale-115 border-teal-600 ring-2 ring-teal-200' : 'border-black/15'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          {/* Size & Eraser */}
          <div className="flex items-center gap-1 border-l border-gray-200 pl-2">
            {SIZES.map((s) => (
              <button
                key={s.label}
                onClick={() => {
                  setBrushSize(s.size);
                  setIsEraser(false);
                }}
                className={`w-8 h-8 rounded-lg font-bold text-xs flex items-center justify-center border transition ${
                  !isEraser && brushSize === s.size
                    ? 'bg-gray-800 text-white border-gray-800'
                    : 'bg-gray-100 text-gray-700 border-gray-300'
                }`}
              >
                {s.label}
              </button>
            ))}

            <button
              onClick={() => setIsEraser(!isEraser)}
              className={`p-2 rounded-lg border transition ${
                isEraser
                  ? 'bg-teal-600 text-white border-teal-600 shadow-inner'
                  : 'bg-gray-100 text-gray-700 border-gray-300'
              }`}
              title="Eraser"
            >
              <Eraser size={16} />
            </button>
          </div>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 relative bg-white overflow-hidden touch-none cursor-crosshair">
          <canvas
            ref={canvasRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="w-full h-full block"
            style={{ touchAction: 'none' }}
          />
        </div>
      </motion.div>
    </div>
  );
};
