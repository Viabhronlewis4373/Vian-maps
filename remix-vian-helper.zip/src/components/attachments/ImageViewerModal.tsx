import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Trash2, Download } from 'lucide-react';
import { Attachment } from '../../types';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface ImageViewerModalProps {
  attachment: Attachment;
  onClose: () => void;
  onDelete?: () => void;
  isEditable?: boolean;
}

export const ImageViewerModal: React.FC<ImageViewerModalProps> = ({
  attachment,
  onClose,
  onDelete,
  isEditable,
}) => {
  const [showConfirm, setShowConfirm] = useState(false);

  return (
    <div className="fixed inset-0 z-[200020] bg-black/90 flex flex-col items-center justify-center p-2 sm:p-4">
      {/* Top Header */}
      <div className="absolute top-0 left-0 right-0 h-16 px-4 flex items-center justify-between z-10 bg-gradient-to-b from-black/80 to-transparent">
        <span className="text-white font-medium text-sm truncate max-w-[200px]">
          {attachment.name || (attachment.type === 'drawing' ? 'Drawing' : 'Image')}
        </span>
        <div className="flex items-center gap-3">
          {attachment.data && (
            <a
              href={attachment.data}
              download={attachment.name || 'attachment.png'}
              className="p-2 text-white/80 hover:text-white transition"
              title="Download"
            >
              <Download size={22} />
            </a>
          )}
          {isEditable && onDelete && (
            <button
              type="button"
              onClick={() => setShowConfirm(true)}
              className="p-2 text-red-400 hover:text-red-300 transition"
              title="Delete"
            >
              <Trash2 size={22} />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white transition"
            title="Close"
          >
            <X size={26} />
          </button>
        </div>
      </div>

      <DeleteConfirmModal
        isOpen={showConfirm}
        title="Delete Attachment?"
        message="Are you sure you want to delete this attachment from this note?"
        onConfirm={() => {
          setShowConfirm(false);
          if (onDelete) onDelete();
          onClose();
        }}
        onCancel={() => setShowConfirm(false)}
      />

      {/* Image Content */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="max-w-full max-h-[85vh] flex items-center justify-center p-2 overflow-auto"
      >
        <img
          src={attachment.data}
          alt={attachment.name || 'Attachment'}
          className="max-w-full max-h-[80vh] object-contain rounded shadow-2xl bg-white/5"
        />
      </motion.div>
    </div>
  );
};
