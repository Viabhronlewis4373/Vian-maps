import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Plus, Trash2, Columns, Rows } from 'lucide-react';
import { Attachment } from '../../types';

interface TableModalProps {
  onSave: (attachment: Attachment) => void;
  onClose: () => void;
  initialTable?: Attachment;
}

export const TableModal: React.FC<TableModalProps> = ({ onSave, onClose, initialTable }) => {
  const [tableName, setTableName] = useState(initialTable?.name || 'Table');
  const [headers, setHeaders] = useState<string[]>(
    initialTable?.headers && initialTable.headers.length > 0
      ? [...initialTable.headers]
      : ['Header 1', 'Header 2', 'Header 3']
  );
  const [rows, setRows] = useState<string[][]>(
    initialTable?.tableData && initialTable.tableData.length > 0
      ? initialTable.tableData.map((r) => [...r])
      : [
          ['', '', ''],
          ['', '', ''],
        ]
  );

  const addColumn = () => {
    const nextColNum = headers.length + 1;
    setHeaders([...headers, `Header ${nextColNum}`]);
    setRows(rows.map((row) => [...row, '']));
  };

  const removeColumn = (colIndex: number) => {
    if (headers.length <= 1) return;
    setHeaders(headers.filter((_, i) => i !== colIndex));
    setRows(rows.map((row) => row.filter((_, i) => i !== colIndex)));
  };

  const addRow = () => {
    setRows([...rows, new Array(headers.length).fill('')]);
  };

  const removeRow = (rowIndex: number) => {
    if (rows.length <= 1) return;
    setRows(rows.filter((_, i) => i !== rowIndex));
  };

  const updateHeader = (index: number, val: string) => {
    const updated = [...headers];
    updated[index] = val;
    setHeaders(updated);
  };

  const updateCell = (rowIndex: number, colIndex: number, val: string) => {
    const updated = rows.map((r, ri) => {
      if (ri === rowIndex) {
        const nextRow = [...r];
        nextRow[colIndex] = val;
        return nextRow;
      }
      return r;
    });
    setRows(updated);
  };

  const handleSave = () => {
    onSave({
      type: 'table',
      name: tableName.trim() || 'Table',
      headers,
      tableData: rows,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200010] bg-black/70 backdrop-blur-sm flex flex-col justify-end sm:justify-center sm:p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="w-full h-full max-w-3xl mx-auto bg-[#F9F9F9] flex flex-col shadow-2xl overflow-hidden sm:rounded-xl sm:h-[85vh]"
      >
        {/* Top Header */}
        <div className="h-16 bg-[#212121] text-white flex items-center justify-between px-3 shrink-0 shadow-md">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full active:scale-95 transition"
            >
              <ArrowLeft size={26} />
            </button>
            <input
              value={tableName}
              onChange={(e) => setTableName(e.target.value)}
              placeholder="Table Name"
              className="bg-transparent border-b border-white/30 text-white font-bold text-lg px-1.5 py-0.5 outline-none focus:border-teal-400 w-40 sm:w-56"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              className="px-4 py-1.5 bg-[#0D9488] hover:bg-[#0F766E] text-white rounded-lg font-bold flex items-center gap-1.5 shadow active:scale-95 transition"
            >
              <Check size={18} strokeWidth={3} />
              <span>Insert</span>
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="bg-white border-b border-gray-200 px-4 py-2.5 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={addColumn}
              className="flex items-center gap-1 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg text-sm font-semibold transition"
            >
              <Columns size={16} />
              <span>+ Column</span>
            </button>
            <button
              onClick={addRow}
              className="flex items-center gap-1 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg text-sm font-semibold transition"
            >
              <Rows size={16} />
              <span>+ Row</span>
            </button>
          </div>

          <span className="text-xs font-medium text-gray-500">
            {rows.length} rows × {headers.length} columns
          </span>
        </div>

        {/* Table Content Area */}
        <div className="flex-1 overflow-auto p-4 bg-white">
          <div className="inline-block min-w-full border border-gray-300 rounded-lg overflow-hidden shadow-sm">
            <table className="min-w-full divide-y divide-gray-300">
              <thead className="bg-[#EFEBE9]">
                <tr>
                  <th className="w-10 px-2 py-2 text-center text-xs font-bold text-gray-500">#</th>
                  {headers.map((h, ci) => (
                    <th key={ci} className="px-2 py-2 text-left relative group">
                      <div className="flex items-center gap-1">
                        <input
                          value={h}
                          onChange={(e) => updateHeader(ci, e.target.value)}
                          className="w-full bg-white/70 border border-gray-300 rounded px-2 py-1 text-sm font-bold text-gray-900 outline-none focus:border-teal-600 focus:bg-white"
                          placeholder={`Header ${ci + 1}`}
                        />
                        {headers.length > 1 && (
                          <button
                            onClick={() => removeColumn(ci)}
                            className="text-gray-400 hover:text-red-500 p-1 opacity-60 hover:opacity-100 transition"
                            title="Remove Column"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {rows.map((row, ri) => (
                  <tr key={ri} className="hover:bg-gray-50/80">
                    <td className="w-10 px-2 py-2 text-center text-xs font-bold text-gray-400 flex items-center justify-center gap-1">
                      <span>{ri + 1}</span>
                      {rows.length > 1 && (
                        <button
                          onClick={() => removeRow(ri)}
                          className="text-gray-300 hover:text-red-500 transition ml-0.5"
                          title="Remove Row"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </td>
                    {row.map((cell, ci) => (
                      <td key={ci} className="px-2 py-1.5">
                        <input
                          value={cell}
                          onChange={(e) => updateCell(ri, ci, e.target.value)}
                          className="w-full bg-transparent border border-gray-200 rounded px-2 py-1 text-sm text-gray-800 outline-none focus:border-teal-600 focus:bg-white transition"
                          placeholder="Cell value..."
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
