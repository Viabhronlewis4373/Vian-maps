import React, { useState } from 'react';
import { Trash2, Edit2, Maximize2, Table as TableIcon } from 'lucide-react';
import { Attachment } from '../../types';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface AttachmentsListProps {
  attachments: Attachment[];
  isEditing: boolean;
  onDeleteAttachment: (index: number) => void;
  onViewImage: (att: Attachment) => void;
  onEditTable: (att: Attachment, index: number) => void;
  title?: string;
}

export const AttachmentsList: React.FC<AttachmentsListProps> = ({
  attachments,
  isEditing,
  onDeleteAttachment,
  onViewImage,
  onEditTable,
  title,
}) => {
  const [indexToDelete, setIndexToDelete] = useState<number | null>(null);

  if (!attachments || attachments.length === 0) return null;

  return (
    <div className="px-4 py-3 space-y-4 border-t border-black/10">
      <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-black/50">
        <span>{title || `Attachments (${attachments.length})`}</span>
      </div>

      <div className="space-y-3">
        {attachments.map((att, idx) => {
          if (att.type === 'image' || att.type === 'drawing') {
            return (
              <div
                key={att.id || idx}
                className="relative group bg-white/60 backdrop-blur-sm rounded-xl border border-black/10 overflow-hidden shadow-sm transition hover:shadow"
              >
                <div
                  className="cursor-pointer max-h-72 flex items-center justify-center bg-black/5 overflow-hidden"
                  onClick={() => onViewImage(att)}
                >
                  <img
                    src={att.data}
                    alt={att.name || 'Attachment'}
                    className="max-h-72 w-auto object-contain transition-transform group-hover:scale-[1.01]"
                  />
                </div>

                <div className="p-2.5 flex items-center justify-between bg-white/80 border-t border-black/5 text-xs">
                  <span className="font-semibold text-gray-700 truncate max-w-[180px]">
                    {att.name || (att.type === 'drawing' ? 'Drawing' : 'Image')}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onViewImage(att)}
                      className="p-1.5 text-gray-600 hover:text-black rounded-lg hover:bg-black/5 transition"
                      title="View Full"
                    >
                      <Maximize2 size={16} />
                    </button>
                    {isEditing && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setIndexToDelete(idx);
                        }}
                        className="p-1.5 text-red-500 hover:text-red-700 rounded-lg hover:bg-red-50 transition"
                        title="Delete Attachment"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          }

          if (att.type === 'table') {
            const headers = att.headers || [];
            const rows = att.tableData || [];

            return (
              <div
                key={att.id || idx}
                className="bg-white/90 backdrop-blur-sm rounded-xl border border-black/10 overflow-hidden shadow-sm"
              >
                {/* Table Header bar */}
                <div className="px-3 py-2 bg-black/5 border-b border-black/10 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-gray-800">
                    <TableIcon size={16} className="text-teal-700" />
                    <span>{att.name || 'Table'}</span>
                  </div>
                  {isEditing && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onEditTable(att, idx)}
                        className="p-1 text-teal-700 hover:text-teal-900 hover:bg-teal-50 rounded transition"
                        title="Edit Table"
                      >
                        <Edit2 size={15} />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIndexToDelete(idx);
                        }}
                        className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition"
                        title="Delete Table"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  )}
                </div>

                {/* Table Content */}
                <div className="overflow-x-auto max-h-64">
                  <table className="min-w-full text-xs divide-y divide-black/10">
                    <thead className="bg-[#FAF8F5]">
                      <tr>
                        {headers.map((h, hi) => (
                          <th
                            key={hi}
                            className="px-3 py-2 text-left font-bold text-gray-700 uppercase tracking-tight whitespace-nowrap"
                          >
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/5 bg-white/70">
                      {rows.map((row, ri) => (
                        <tr key={ri} className="hover:bg-black/5 transition">
                          {row.map((cell, ci) => (
                            <td key={ci} className="px-3 py-1.5 text-gray-800 whitespace-nowrap">
                              {cell || '—'}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          }

          return null;
        })}
      </div>

      <DeleteConfirmModal
        isOpen={indexToDelete !== null}
        title="Delete Attachment?"
        message="Are you sure you want to remove this attachment from this note?"
        onConfirm={() => {
          if (indexToDelete !== null) {
            onDeleteAttachment(indexToDelete);
            setIndexToDelete(null);
          }
        }}
        onCancel={() => setIndexToDelete(null)}
      />
    </div>
  );
};
