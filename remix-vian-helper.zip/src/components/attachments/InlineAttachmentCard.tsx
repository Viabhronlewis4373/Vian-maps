import React, { useState } from 'react';
import { Maximize2, Trash2, Edit2, Table as TableIcon } from 'lucide-react';
import { Attachment } from '../../types';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface InlineAttachmentCardProps {
  attachment: Attachment;
  onViewImage: (att: Attachment) => void;
  onEditTable?: (att: Attachment) => void;
  onDelete?: (att: Attachment) => void;
  isEditing?: boolean;
}

export const InlineAttachmentCard: React.FC<InlineAttachmentCardProps> = ({
  attachment,
  onViewImage,
  onEditTable,
  onDelete,
  isEditing,
}) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  if (attachment.type === 'image' || attachment.type === 'drawing') {
    return (
      <div className="my-2.5 rounded-xl border border-black/15 overflow-hidden bg-white/70 shadow-sm backdrop-blur-sm transition hover:shadow">
        <div
          className="cursor-pointer max-h-72 flex items-center justify-center bg-black/5 overflow-hidden"
          onClick={() => onViewImage(attachment)}
        >
          <img
            src={attachment.data}
            alt={attachment.name || 'Attachment'}
            className="max-h-72 w-auto object-contain transition-transform hover:scale-[1.01]"
          />
        </div>

        <div className="px-3 py-2 flex items-center justify-between bg-white/90 border-t border-black/10 text-xs">
          <span className="font-semibold text-gray-800 truncate max-w-[200px]">
            {attachment.name || (attachment.type === 'drawing' ? 'Drawing' : 'Image')}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onViewImage(attachment)}
              className="p-1.5 text-gray-600 hover:text-black rounded-lg hover:bg-black/5 transition"
              title="View Full"
            >
              <Maximize2 size={16} />
            </button>
            {onDelete && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="p-1.5 text-red-500 hover:text-red-700 rounded-lg hover:bg-red-50 transition"
                title="Delete Attachment"
              >
                <Trash2 size={16} />
              </button>
            )}
          </div>
        </div>

        <DeleteConfirmModal
          isOpen={showDeleteConfirm}
          title="Delete Attachment?"
          message="Are you sure you want to remove this attachment from this note?"
          onConfirm={() => {
            setShowDeleteConfirm(false);
            if (onDelete) onDelete(attachment);
          }}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      </div>
    );
  }

  if (attachment.type === 'table') {
    const headers = attachment.headers || [];
    const rows = attachment.tableData || [];

    return (
      <div className="my-2.5 rounded-xl border border-black/15 overflow-hidden bg-white/90 shadow-sm">
        {/* Table top bar */}
        <div className="px-3 py-2 bg-black/5 border-b border-black/10 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-bold text-gray-800">
            <TableIcon size={16} className="text-teal-700" />
            <span>{attachment.name || 'Table'}</span>
          </div>
          <div className="flex items-center gap-1">
            {onEditTable && (
              <button
                type="button"
                onClick={() => onEditTable(attachment)}
                className="p-1 text-teal-700 hover:text-teal-900 hover:bg-teal-50 rounded transition"
                title="Edit Table"
              >
                <Edit2 size={15} />
              </button>
            )}
            {onDelete && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition"
                title="Delete Table"
              >
                <Trash2 size={15} />
              </button>
            )}
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto max-h-64">
          <table className="min-w-full text-xs divide-y divide-black/10">
            <thead className="bg-[#FAF8F5]">
              <tr>
                {headers.map((h, hi) => (
                  <th
                    key={hi}
                    className="px-3 py-2 text-left font-bold text-gray-700 uppercase tracking-tight whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5 bg-white/70">
              {rows.map((row, ri) => (
                <tr key={ri} className="hover:bg-black/5 transition">
                  {row.map((cell, ci) => (
                    <td key={ci} className="px-3 py-1.5 text-gray-800 whitespace-nowrap">
                      {cell || '—'}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <DeleteConfirmModal
          isOpen={showDeleteConfirm}
          title="Delete Table?"
          message="Are you sure you want to remove this table from this note?"
          onConfirm={() => {
            setShowDeleteConfirm(false);
            if (onDelete) onDelete(attachment);
          }}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      </div>
    );
  }

  return null;
};
