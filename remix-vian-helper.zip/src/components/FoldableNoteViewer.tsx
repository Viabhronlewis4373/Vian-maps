import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Folder, FolderOpen } from 'lucide-react';
import { parseNoteBody, NoteSegment } from '../utils/foldParser';
import { Attachment } from '../types';
import { InlineAttachmentCard } from './attachments/InlineAttachmentCard';

interface FoldableNoteViewerProps {
  body: string;
  attachments?: Attachment[];
  colorObj: { name: string; bg: string; border: string; text?: string };
  onDoubleClick: (e: React.MouseEvent | React.TouchEvent) => void;
  onViewImage?: (att: Attachment) => void;
  onEditTable?: (att: Attachment) => void;
  onDeleteAttachment?: (att: Attachment) => void;
  isEditing?: boolean;
}

export const FoldableNoteViewer: React.FC<FoldableNoteViewerProps> = ({
  body,
  attachments = [],
  colorObj,
  onDoubleClick,
  onViewImage = () => {},
  onEditTable,
  onDeleteAttachment,
  isEditing = false,
}) => {
  const segments = useMemo(() => parseNoteBody(body || ''), [body]);

  // Collapsed by default: all folds start collapsed!
  const [openFolds, setOpenFolds] = useState<Record<string, boolean>>({});

  const toggleFold = (foldId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenFolds((prev) => ({
      ...prev,
      [foldId]: !prev[foldId],
    }));
  };

  const lineStyle = {
    backgroundImage: `repeating-linear-gradient(transparent, transparent 47px, ${colorObj.border}33 47px, ${colorObj.border}33 48px)`,
    backgroundSize: '100% 48px',
    backgroundPosition: '0 -3px',
    backgroundAttachment: 'local',
  };

  const findAttachment = (idOrIndex: string): Attachment | undefined => {
    // 1. match by id
    const byId = attachments.find((a) => a.id === idOrIndex);
    if (byId) return byId;

    // 2. fallback to index if numerical
    const num = parseInt(idOrIndex, 10);
    if (!isNaN(num) && attachments[num]) {
      return attachments[num];
    }
    return undefined;
  };

  const renderInnerSegment = (seg: NoteSegment, indexKey: string | number) => {
    if (seg.type === 'text') {
      if (!seg.content) return null;
      return (
        <div
          key={indexKey}
          className="text-2xl font-medium leading-[48px] whitespace-pre-wrap break-words"
        >
          {seg.content}
        </div>
      );
    }

    if (seg.type === 'attachment') {
      const att = findAttachment(seg.attachmentId);
      if (!att) {
        return (
          <div
            key={indexKey}
            className="my-2 px-3 py-1.5 rounded bg-black/5 text-xs text-gray-500 italic border border-black/10 flex items-center justify-between"
          >
            <span>[Missing or deleted attachment: {seg.attachmentId}]</span>
            {onDeleteAttachment && (
              <button
                type="button"
                onClick={() => onDeleteAttachment({ type: 'image', id: seg.attachmentId })}
                className="text-red-500 hover:text-red-700 font-bold ml-2"
              >
                Clear Tag
              </button>
            )}
          </div>
        );
      }

      return (
        <div key={indexKey} className="py-1">
          <InlineAttachmentCard
            attachment={att}
            onViewImage={onViewImage}
            onEditTable={onEditTable}
            onDelete={onDeleteAttachment}
            isEditing={isEditing}
          />
        </div>
      );
    }

    return null;
  };

  return (
    <div
      className="w-full px-4 pt-2 pb-12 select-text cursor-default font-medium text-black min-h-full"
      style={lineStyle}
      onDoubleClick={onDoubleClick}
      onClick={(e) => {
        if (e.detail === 2) onDoubleClick(e);
      }}
    >
      {segments.length === 0 && (
        <div className="text-black/30 italic text-xl leading-[48px] py-2">
          (Empty note - double tap or tap Edit to write)
        </div>
      )}

      {segments.map((seg, idx) => {
        if (seg.type === 'text' || seg.type === 'attachment') {
          return renderInnerSegment(seg, `seg_${idx}`);
        }

        if (seg.type === 'fold') {
          const isOpen = Boolean(openFolds[seg.id]);

          return (
            <div
              key={seg.id}
              className="my-3 rounded-lg overflow-hidden border border-black/15 shadow-sm bg-white/70 backdrop-blur-sm transition-all"
            >
              {/* Fold Header (Click to toggle) */}
              <div
                onClick={(e) => toggleFold(seg.id, e)}
                className="flex items-center justify-between px-3.5 py-3 cursor-pointer select-none bg-black/5 hover:bg-black/10 active:bg-black/15 transition-colors"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <motion.div
                    animate={{ rotate: isOpen ? 90 : 0 }}
                    transition={{ duration: 0.15 }}
                    className="text-black/70 shrink-0"
                  >
                    <ChevronRight size={22} strokeWidth={2.5} />
                  </motion.div>

                  <div className="text-black/70 shrink-0">
                    {isOpen ? <FolderOpen size={20} /> : <Folder size={20} />}
                  </div>

                  <span className="font-bold text-lg sm:text-xl text-black truncate">
                    {seg.title}
                  </span>

                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-black/10 text-black/70 shrink-0">
                    {seg.lineCount} {seg.lineCount === 1 ? 'line' : 'lines'}
                  </span>
                </div>

                <span className="text-xs font-medium text-black/50 tracking-tight shrink-0 ml-2">
                  {isOpen ? 'Tap to fold' : 'Tap to unfold'}
                </span>
              </div>

              {/* Fold Content (Collapsible) */}
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2, ease: 'easeInOut' }}
                    className="overflow-hidden border-t border-black/10 bg-white/40"
                  >
                    <div
                      className="px-4 py-2 border-l-4"
                      style={{
                        borderColor: colorObj.border,
                        ...lineStyle,
                      }}
                    >
                      {seg.innerSegments && seg.innerSegments.length > 0 ? (
                        seg.innerSegments.map((innerSeg, i) =>
                          renderInnerSegment(innerSeg, `inner_${seg.id}_${i}`)
                        )
                      ) : (
                        <div className="text-black/30 italic text-lg leading-[48px]">
                          (Empty folded section)
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        }

        return null;
      })}
    </div>
  );
};
