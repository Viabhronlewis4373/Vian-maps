export interface NormalSegment {
  type: 'text';
  content: string;
}

export interface AttachmentSegment {
  type: 'attachment';
  id: string;
  attachmentId: string;
  label?: string;
}

export interface FoldSegment {
  type: 'fold';
  id: string;
  title: string;
  content: string;
  lineCount: number;
  innerSegments: (NormalSegment | AttachmentSegment)[];
}

export type NoteSegment = NormalSegment | AttachmentSegment | FoldSegment;

/**
 * Regex to match [fold: Title] ... [/fold] or [fold] ... [/fold]
 * Supports optional title after colon.
 */
const FOLD_REGEX = /\[fold(?::\s*([^\n\]]*))?\]([\s\S]*?)\[\/fold\]/gi;

/**
 * Regex to match [attachment: ATTACHMENT_ID] or [attachment: ATTACHMENT_ID : Optional Label]
 */
export const ATTACHMENT_TAG_REGEX = /\[attachment:\s*([a-zA-Z0-9_\-]+)(?::\s*([^\n\]]*))?\]/gi;

/**
 * Parses a plain text block into text and inline attachment segments.
 */
export function parseTextWithAttachments(text: string = ''): (NormalSegment | AttachmentSegment)[] {
  if (!text) return [];

  const segments: (NormalSegment | AttachmentSegment)[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  ATTACHMENT_TAG_REGEX.lastIndex = 0;

  while ((match = ATTACHMENT_TAG_REGEX.exec(text)) !== null) {
    const matchIndex = match.index;
    const fullMatch = match[0];
    const attachmentId = (match[1] || '').trim();
    const label = (match[2] || '').trim();

    if (matchIndex > lastIndex) {
      const textBefore = text.slice(lastIndex, matchIndex);
      if (textBefore.length > 0) {
        segments.push({
          type: 'text',
          content: textBefore,
        });
      }
    }

    segments.push({
      type: 'attachment',
      id: `att_seg_${matchIndex}_${attachmentId}`,
      attachmentId,
      label,
    });

    lastIndex = matchIndex + fullMatch.length;
  }

  if (lastIndex < text.length) {
    const textAfter = text.slice(lastIndex);
    if (textAfter.length > 0) {
      segments.push({
        type: 'text',
        content: textAfter,
      });
    }
  }

  return segments;
}

/**
 * Parses note body into sequential text, attachment, and fold segments.
 */
export function parseNoteBody(body: string = ''): NoteSegment[] {
  if (!body) return [];

  const segments: NoteSegment[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  FOLD_REGEX.lastIndex = 0;

  while ((match = FOLD_REGEX.exec(body)) !== null) {
    const matchIndex = match.index;
    const fullMatch = match[0];
    const rawTitle = (match[1] || '').trim();
    const foldContent = match[2] || '';

    // If there was text before this fold, parse attachments inside it
    if (matchIndex > lastIndex) {
      const textBefore = body.slice(lastIndex, matchIndex);
      const innerBefore = parseTextWithAttachments(textBefore);
      segments.push(...innerBefore);
    }

    // Count lines in folded content
    const lines = foldContent.split('\n');
    const lineCount = lines.filter(l => l.trim().length > 0).length || lines.length;

    // Parse attachments that may reside inside the fold itself
    const foldInnerSegments = parseTextWithAttachments(foldContent);

    segments.push({
      type: 'fold',
      id: `fold_${matchIndex}_${lastIndex}`,
      title: rawTitle || 'Folded Section',
      content: foldContent,
      lineCount,
      innerSegments: foldInnerSegments,
    });

    lastIndex = matchIndex + fullMatch.length;
  }

  // Trailing text after last fold
  if (lastIndex < body.length) {
    const textAfter = body.slice(lastIndex);
    const innerAfter = parseTextWithAttachments(textAfter);
    segments.push(...innerAfter);
  }

  return segments;
}

/**
 * Inserts or wraps a fold block at the current cursor or selection in a text note.
 */
export function insertFoldAtPosition(
  text: string,
  start: number,
  end: number,
  foldTitle: string = 'Section'
): { newText: string; selectionStart: number; selectionEnd: number } {
  const title = foldTitle.trim() || 'Section';
  const before = text.substring(0, start);
  const selected = text.substring(start, end);
  const after = text.substring(end);

  const startMarker = `[fold: ${title}]\n`;
  const endMarker = `\n[/fold]`;

  if (selected.length > 0) {
    // Wrap selection
    const innerContent = selected;
    const newText = before + startMarker + innerContent + endMarker + after;
    const newStart = before.length + startMarker.length;
    const newEnd = newStart + innerContent.length;
    return { newText, selectionStart: newStart, selectionEnd: newEnd };
  } else {
    // Insert new template between 2 lines
    const placeholder = 'Type between these 2 lines...';
    const needsLeadingNewline = before.length > 0 && !before.endsWith('\n');
    const prefix = needsLeadingNewline ? '\n' : '';
    
    const newText = before + prefix + startMarker + placeholder + endMarker + after;
    const newStart = before.length + prefix.length + startMarker.length;
    const newEnd = newStart + placeholder.length;
    return { newText, selectionStart: newStart, selectionEnd: newEnd };
  }
}

/**
 * Inserts an attachment tag at the exact cursor position in the note body.
 */
export function insertAttachmentAtPosition(
  text: string,
  cursorPos: number,
  attachmentId: string,
  attachmentName?: string
): { newText: string; newCursorPos: number } {
  const safePos = Math.max(0, Math.min(cursorPos, text.length));
  const before = text.substring(0, safePos);
  const after = text.substring(safePos);

  const cleanLabel = (attachmentName || '').trim().replace(/[\]\n]/g, '');
  const labelSuffix = cleanLabel ? ` : ${cleanLabel}` : '';
  const token = `[attachment: ${attachmentId}${labelSuffix}]`;

  const needsLeadingNewline = before.length > 0 && !before.endsWith('\n');
  const needsTrailingNewline = after.length > 0 && !after.startsWith('\n');

  const insertString = `${needsLeadingNewline ? '\n' : ''}${token}${needsTrailingNewline ? '\n' : ''}`;
  const newText = before + insertString + after;
  const newCursorPos = before.length + insertString.length;

  return { newText, newCursorPos };
}

/**
 * Removes any [attachment: ATTACHMENT_ID] tag from the note body when deleted.
 */
export function removeAttachmentFromText(text: string, attachmentId: string): string {
  if (!text || !attachmentId) return text;
  const escapedId = attachmentId.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
  const regex = new RegExp(`(\\n)?\\[attachment:\\s*${escapedId}(?::[^\\]]*)?\\](\\n)?`, 'gi');
  return text.replace(regex, (match, p1, p2) => {
    // If surrounded by newlines, keep a single newline
    if (p1 && p2) return '\n';
    return '';
  });
}
